#include<reg52.h>
#define uchar unsigned char
#define uint unsigned int
//==============================================================================================
// File Name   : lesson1_3.c
// Function    : Cellphone controls car to run forward and backward. And it can also get the car status.
// Date        : January 24, 2016
// Version     : 0.1
// Author      : lpstudy
// Mail        : lpstudy@qq.com
// Proffession : research work
// Copyright (c) You can distribute it in any way. If you can reserve this part, I will be grateful.
//==============================================================================================

//00 stop, 01 forward, 10 backward
//wheel_x_y (x is the id of wheel, y is the two input ports for this wheel id)
//wheel: fron-left=4, front-right=3, back-left=2, back-right=1
sbit wheel_1_1 = P2^0;
sbit wheel_1_2 = P2^1;
sbit wheel_2_1 = P2^2;
sbit wheel_2_2 = P2^3;
sbit wheel_3_1 = P2^4;
sbit wheel_3_2 = P2^5;
sbit wheel_4_1 = P2^6;
sbit wheel_4_2 = P2^7;

//Led for some test
sbit LED=P0^0;


char direc=-1;
char lastDirec=-1;
char isCmdFlag = 0;

//Timer0 
typedef enum{
	TimerDelay10ms=0,
	TimerDelay50ms=1,
	TimerDelay100ms=2,
	TimerDelay200ms=3,
	TimerDelay500ms=4,
	TimerDelay1000ms=5,
	TimerDelay2000ms=6,
}TimerDelayType;
TimerDelayType timerDelay = TimerDelay1000ms; 
uchar timerDealyCount=0;
uchar maxTimerDelayCount=1;


void restartTimer0();
void carStop();

//6M hz to delay 10ms
void Delay10ms(unsigned int c)
{
    unsigned char a, b;
    for (;c>0;c--)
	{
		for (b=18;b>0;b--)
		{
			for (a=137;a>0;a--);
		}
	}       
}
//6Mhz to delay 1ms
void Delay1ms(unsigned int c)
{
    unsigned char a, b;
    for (;c>0;c--)
	{
		for (b=17;b>0;b--)
		{
			for (a=13;a>0;a--);
		}
	}    	
}
void Delay10us(unsigned int c)
{
    unsigned char a;
    for (;c>0;c--)
	{
		for (a=5;a>0;a--);
	}  
}
void zeroPorts()
{
	wheel_1_1 = 0;
	wheel_1_2 = 0;
	wheel_2_1 = 0;
	wheel_2_2 = 0;
	wheel_3_1 = 0;
	wheel_3_2 = 0;
	wheel_4_1 = 0;
	wheel_4_2 = 0;
}
void onPorts()
{
	wheel_1_1 = 1;
	wheel_1_2 = 1;
	wheel_2_1 = 1;
	wheel_2_2 = 1;
	wheel_3_1 = 1;
	wheel_3_2 = 1;
	wheel_4_1 = 1;
	wheel_4_2 = 1;
}
void testAllPorts()
{
	while(1){
		Delay10ms(100);
		LED = 0;
		zeroPorts();
		Delay10ms(100);
		onPorts();
		LED= 1 ;
	}
}
void wheelForward(uchar which)
{
	switch(which)
	{
		case 1:
		{	
			wheel_1_1 = 0;
			wheel_1_2 = 1;
			break;
		}
		case 2:
		{
			wheel_2_1 = 0;
			wheel_2_2 = 1;
			break;
		}
		case 3:
		{
			wheel_3_1 = 0;
			wheel_3_2 = 1;
			break;		
		}
		case 4:
		{
			wheel_4_1 = 0;
			wheel_4_2 = 1;
			break;
		}
	}
}
void wheelBackward(uchar which)
{
	switch(which)
	{
		case 1:
		{	
			wheel_1_1 = 1;
			wheel_1_2 = 0;
			break;
		}
		case 2:
		{
			wheel_2_1 = 1;
			wheel_2_2 = 0;
			break;
		}
		case 3:
		{
			wheel_3_1 = 1;
			wheel_3_2 = 0;
			break;		
		}
		case 4:
		{
			wheel_4_1 = 1;
			wheel_4_2 = 0;
			break;
		}
	}
}
void wheelStop(uchar which)
{
	switch(which)
	{
		case 1:
		{	
			wheel_1_1 = 0;
			wheel_1_2 = 0;
			break;
		}
		case 2:
		{
			wheel_2_1 = 0;
			wheel_2_2 = 0;
			break;
		}
		case 3:
		{
			wheel_3_1 = 0;
			wheel_3_2 = 0;
			break;		
		}
		case 4:
		{
			wheel_4_1 = 0;
			wheel_4_2 = 0;
			break;
		}
	}
}
//1 for running, 0 for stop
uchar isWheelRun(uchar which)
{
	switch(which)
	{
		case 1:
		{	
			if(wheel_1_1 == 0 && wheel_1_2 == 0)
				return 0;
			break;
		}
		case 2:
		{
			if(wheel_2_1 == 0 && wheel_2_2 == 0)
				return 0;
			break;
		}
		case 3:
		{
			if(wheel_3_1 == 0 && wheel_3_2 == 0)
				return 0;
			break;		
		}
		case 4:
		{
			if(wheel_4_1 == 0 && wheel_4_2 == 0 )
				return 0;
			break;
		}
	}

	return 1;
}

void wheelReverse(uchar which)
{
	switch(which)
	{
		case 1:
		{	
			wheel_1_1 = !wheel_1_1;
			wheel_1_2 = !wheel_1_2;
			break;
		}
		case 2:
		{
			wheel_2_1 = !wheel_2_1;
			wheel_2_2 = !wheel_2_2;
			break;
		}
		case 3:
		{
			wheel_3_1 = !wheel_3_1;
			wheel_3_2 = !wheel_3_2;
			break;		
		}
		case 4:
		{
			wheel_4_1 = !wheel_4_1;
			wheel_4_2 = !wheel_4_2;
			break;
		}
	}
}

void carForward()
{
	uchar i;

	//now is backward
	if(lastDirec==5){
		 direc=-1;//wait for backward to be finished.
		 return;
	}

	for(i = 1; i <= 4; ++i)
		wheelForward(i);
}
void carBackward()
{
	uchar i;

    //now is forward.
	if(lastDirec==4 || lastDirec==6 || lastDirec==7){
		 direc=-1;	//wait for this to be finished
		 return;
	}

	for(i = 1; i <= 4; ++i)
		wheelBackward(i);
}
void carStop()
{
	uchar i;
	for(i = 1; i <= 4; ++i)
		wheelStop(i);
}
void carLeft()
{
	wheelStop(2);
	wheelForward(1);
	wheelStop(4);
	wheelForward(3);
}
void carRight()
{
	wheelStop(1);
	wheelForward(2);
	wheelStop(3);
	wheelForward(4);
}
void wheelTest(uchar wheel)
{
	if(isWheelRun(wheel) == 0){
		carStop();
		Delay10ms(10);
		wheelForward(wheel);
	}
	else{
		carStop();
		Delay10ms(10);
		wheelBackward(wheel);	
	}
}

void sendChar (uchar c)
{
    SBUF =c  ;
    while(!TI);
    TI=0;
}
void sendSerialString(uchar* s)
{
  while(*s!='\0')
  {
     sendChar(*s);
     s++;
	 Delay1ms(1);//delay 100us. Baud 2400bps. one bit for 0.44ms
  }
}

void initChip()
{
	 zeroPorts();

	 //timer T1 for serial baud
	 TMOD=0x21;	  
	 //TH1=0xfd;  TL1=0xfd;   for 11.0592MHZ and SMOD=0, 
	 TH1 = 0xf3;//2400bps
	 TL1 = 0xf3;
	 TR1=1;    // T1

	 //timer T0
     TH0=0XEC;	//10ms, 6M Hz
	 TL0=0X78;
	 TR0=1;

	 //SCON: 0x50=SM0=0, SM1=1,REN=1
	 REN=1;   
	 SM0=0;
	 SM1=1; 
     PCON = 0x80;		//SMOD=1;

	 ES=1; 	//serial interrupt
	 ET0=1; //Timer0 interrupt
	 EA=1; //Interrupt Control

	 sendSerialString("car bluetooth program init finished\n");
}
void main()							
{	
	initChip();
												   
	while(1)
	{
	    if(isCmdFlag == 0){
			continue;
		}
		//����ע�ͣ� ��ĶԲ�ס����Ϊʹ��Ӣ�ĵĻ�̫�Ѷ����ˡ�
		//�յ��������ÿ�����������ʱ��Ϊ10ms,����10ms��û�������յ���С��ֹͣ(��ʵӦ��EN�ڲ��Ӹߵ�ƽ������)
		//���10ms���ƣ�һ��������������switch����֮�󣬲���Delay�ķ�ʽ����������main�е�whileѭ���ͻ��еȴ�������
		//������ܻ��������������ˣ���ߵ�main����ִ��Delay�����������ӳ١�
		//��һ���棬���ձ�ķ����ǲ��ö�ʱ����������ʱ10ms�����10ms�Ѿ����ˣ�����ֹС�������С����û��10ms�����������յ��µ����
		//������µ������������Ч��ͨ�����ö�ʱ�����ɡ���Ϊmain��whileѭ��û��Delay������
		isCmdFlag = 0;
		switch (direc)
		{
			 case -1: carStop();     break;
			 case  0: LED = !LED;      break;  //to show information by LED
			 case  4: restartTimer0(); carForward();  break;
			 case  5: restartTimer0(); carBackward(); break;
			 case  6: restartTimer0(); carLeft();     break;
			 case  7: restartTimer0(); carRight();    break;
			 //wheel test
			 case 11: restartTimer0(); wheelTest(1); break;
			 case 12: restartTimer0(); wheelTest(2); break;
			 case 13: restartTimer0(); wheelTest(3); break;
			 case 14: restartTimer0(); wheelTest(4); break;
		 }
		 //Delay10ms(100);
	}
}

void reloadTimer0()
{
	switch(timerDelay)
	{
		case TimerDelay10ms:
		{
     		TH0=0XEC;	//10ms, 6M Hz
	 		TL0=0X78;
			maxTimerDelayCount=1;
			break;
		}
		case TimerDelay50ms:
		{
			TH0=0X9E;	//50ms, 6M Hz
	 		TL0=0X58;
			maxTimerDelayCount=1;
			break;
		}
		case TimerDelay100ms:
		{
			TH0=0X3C;	//100ms, 6M Hz
	 		TL0=0XB0;
			maxTimerDelayCount=1;
			break;
		}
		case TimerDelay200ms:
		{
 			TH0=0X3C;	//100ms, 6M Hz
	 		TL0=0XB0;
			maxTimerDelayCount=1;
			break;
		}
		case TimerDelay500ms:
		{
			TH0=0X3C;	//500ms, 6M Hz
	 		TL0=0XB0;
			maxTimerDelayCount=5;
			break;
		}
		case TimerDelay1000ms:
		{
			TH0=0X3C;	//1000ms, 6M Hz
	 		TL0=0XB0;
			maxTimerDelayCount=10;
			break;
		}
		case TimerDelay2000ms:
		{
			TH0=0X3C;	//2000ms, 6M Hz
	 		TL0=0XB0;
			maxTimerDelayCount=20;
			break;
		}
	}
}


const uchar*  timerDelayStr()
{
	switch(timerDelay)
	{
		case TimerDelay10ms:
		{
			return "10ms";
		}
		case TimerDelay50ms:
		{
			return "50ms";
		}
		case TimerDelay100ms:
		{
			return "100ms";
		}
		case TimerDelay200ms:
		{
			return "200ms";
		}
		case TimerDelay500ms:
		{
			return "500ms";
		}
		case TimerDelay1000ms:
		{
			return "1000ms";
		}
		case TimerDelay2000ms:
		{
			return "2000ms";
		}
	}
}
//when the serial port interrupt, the timer needs to be restart for next cycle.
void restartTimer0()
{
	TR0 = 0; //stop timer
	reloadTimer0();
	timerDealyCount = 0;
	TR0 = 1;//start timer
}

//this is controlled by serial port. That is, we can adjust the dealy with bluetooth.
void restartTimer0WithDelay(TimerDelayType newDelay)
{
	timerDelay = newDelay;
	restartTimer0();
}

//Timer0 to stop motor, the interrupt number is 1
void timer0() interrupt 1 
{
    timerDealyCount++;
    if(	timerDealyCount >= 	maxTimerDelayCount){
		//reach the time delay, so stop the motor.
		direc=-1;
		carStop();
		timerDealyCount = 0;
	}

	reloadTimer0();//reload the initial value for Timer0
}
//attention!
//This is processed in serial recv interrupt. And it should be executed in the main function.
//For simplicity, I just deal with it here.
void getCarInfo()
{
	sendSerialString("car delay:");
	sendSerialString(timerDelayStr());
	sendSerialString("\n");

	sendSerialString("car speed: full speed\n");
}

void help()
{
	sendSerialString("Usage:\r\n");
    sendSerialString("      f -> car front\n");
	sendSerialString("      b -> car back\n");
	sendSerialString("      l -> car turn left\n");
	sendSerialString("      r -> car turn right\n");
	sendSerialString("      s -> car stop\n");
	sendSerialString("      1 -> wheel right back\n");
	sendSerialString("      2 -> wheel left back\n");
	sendSerialString("      3 -> wheel right front\n");
	sendSerialString("      4 -> wheel left front\n");
	sendSerialString("      5 -> cmd to delay 10ms\n");
	sendSerialString("      6 -> cmd to delay 100ms\n");
	sendSerialString("      7 -> cmd to delay 500ms\n");
	sendSerialString("      8 -> cmd to delay 10000ms\n");
	sendSerialString("      9 -> cmd to delay 20000ms\n");

	sendSerialString("      i -> cmd to get car info\n");
	sendSerialString("      h -> show help\n\n");
}

//serial interrupt
void serial() interrupt 4
{
	 char sbuf;
	 sbuf=SBUF;
	 isCmdFlag = 1;
	 lastDirec = direc;
	 switch (sbuf)
	 {
		 case 'f': direc=4; break;
		 case 'b': direc=5; break;
		 case 'l': direc=6; break;
		 case 'r': direc=7; break;
		 case 's': direc=-1; break;
		 case '1': direc = 11; break;
		 case '2': direc=12; break;
		 case '3': direc =13; break;
		 case '4': direc=14; break;

		 //for serial port to control delay
		 case '5': restartTimer0WithDelay(TimerDelay10ms);   direc= 0;break;
		 case '6': restartTimer0WithDelay(TimerDelay100ms);  direc= 0; break;
		 case '7': restartTimer0WithDelay(TimerDelay500ms);  direc= 0; break;
		 case '8': restartTimer0WithDelay(TimerDelay1000ms); direc= 0;break;
		 case '9': restartTimer0WithDelay(TimerDelay2000ms); direc= 0; break;

		 //command to get car information.
		 case 'i': getCarInfo(); direc= 0; break;
		 case 'h': help(); direc= 0; break;

		 default : direc= 0; break;//for LED
	 }
	 RI=0;
} 